import { format } from 'sql-formatter';

interface ConversionResult {
  success: boolean;
  sql?: string;
  warnings?: string[];
  errors?: string[];
}

export class SQLConverter {
  private warnings: string[] = [];

  convert(hiveSQL: string): ConversionResult {
    try {
      // Clean and preprocess SQL
      let sql = this.preprocessSQL(hiveSQL);
      
      // Convert specific Hive constructs
      sql = this.convertCreateTable(sql);
      sql = this.convertInsertStatements(sql);
      sql = this.convertFunctions(sql);
      sql = this.convertLateralView(sql);
      sql = this.convertDataTypes(sql);
      
      return {
        success: true,
        sql: this.formatSQL(sql),
        warnings: this.warnings
      };
    } catch (error) {
      return {
        success: false,
        errors: [error instanceof Error ? error.message : 'Unknown error'],
        warnings: this.warnings
      };
    }
  }

  private preprocessSQL(sql: string): string {
    // Remove SET statements
    sql = sql.replace(/^SET\s+[^;]+;/gm, '');
    
    // Remove Hive hints
    sql = sql.replace(/\/\*\+\s*(?:MAPJOIN|STREAMTABLE|BROADCAST)\([^)]*\)\s*\*\//g, '');
    
    // Clean up whitespace
    return sql.replace(/\s+/g, ' ').trim();
  }

  private convertCreateTable(sql: string): string {
    // Convert CREATE TABLE syntax
    sql = sql.replace(
      /CREATE\s+(?:EXTERNAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)/gi,
      'CREATE OR REPLACE TABLE $1'
    );

    // Remove PARTITIONED BY clause
    sql = sql.replace(/PARTITIONED\s+BY\s*\([^)]+\)/gi, '');

    // Remove CLUSTERED BY clause
    if (sql.match(/CLUSTERED\s+BY/i)) {
      this.warnings.push("Snowflake doesn't support CLUSTER BY. Removing it.");
      sql = sql.replace(/CLUSTERED\s+BY\s*\([^)]+\)\s+INTO\s+\d+\s+BUCKETS/gi, '');
    }

    // Remove storage clauses
    sql = sql.replace(/STORED\s+AS\s+\w+/gi, '');
    sql = sql.replace(/ROW\s+FORMAT\s+[^;]+/gi, '');
    sql = sql.replace(/LOCATION\s+\'[^\']+\'/gi, '');
    sql = sql.replace(/TBLPROPERTIES\s*\([^)]*\)/gi, '');

    return sql;
  }

  private convertInsertStatements(sql: string): string {
    // Convert INSERT INTO TABLE to INSERT INTO
    sql = sql.replace(/INSERT\s+INTO\s+TABLE\s+/gi, 'INSERT INTO ');

    // Convert INSERT OVERWRITE
    if (sql.match(/INSERT\s+OVERWRITE/i)) {
      this.warnings.push("Converting INSERT OVERWRITE to INSERT INTO");
      sql = sql.replace(/INSERT\s+OVERWRITE\s+(?:TABLE\s+)?(\w+)/gi, 'INSERT INTO $1');
    }

    // Remove PARTITION clause
    sql = sql.replace(/PARTITION\s*\([^)]+\)/gi, '');

    return sql;
  }

  private convertFunctions(sql: string): string {
    // Date/Time functions
    sql = sql.replace(
      /unix_timestamp\(([^)]*)\)/gi,
      (match, args) => args ? 
        `TO_NUMBER(${args}::timestamp_tz AT TIME ZONE 'UTC')` : 
        `TO_NUMBER(CURRENT_TIMESTAMP(3)::timestamp_tz AT TIME ZONE 'UTC')`
    );

    sql = sql.replace(
      /from_unixtime\(([^)]+)\)/gi,
      'TO_TIMESTAMP($1)'
    );

    // Collection functions
    sql = sql.replace(
      /collect_set\(([^)]+)\)/gi,
      'ARRAY_AGG(DISTINCT $1)'
    );

    sql = sql.replace(
      /collect_list\(([^)]+)\)/gi,
      'ARRAY_AGG($1)'
    );

    // JSON functions
    sql = sql.replace(
      /get_json_object\(([^,]+),\s*([^)]+)\)/gi,
      'GET_PATH(PARSE_JSON($1), $2)'
    );

    return sql;
  }

  private convertLateralView(sql: string): string {
    // Convert LATERAL VIEW EXPLODE to FLATTEN
    if (sql.match(/LATERAL\s+VIEW\s+EXPLODE/i)) {
      this.warnings.push("Converting LATERAL VIEW EXPLODE to Snowflake's FLATTEN");
      sql = sql.replace(
        /LATERAL\s+VIEW\s+(?:OUTER\s+)?EXPLODE\s*\(([^)]+)\)\s+(\w+)\s+AS\s+(\w+)/gi,
        'CROSS JOIN TABLE(FLATTEN(input => $1)) AS $2($3)'
      );
    }
    return sql;
  }

  private convertDataTypes(sql: string): string {
    const typeMap: Record<string, string> = {
      'STRING': 'VARCHAR',
      'INT': 'NUMBER(38,0)',
      'INTEGER': 'NUMBER(38,0)',
      'BIGINT': 'NUMBER(38,0)',
      'SMALLINT': 'NUMBER(5,0)',
      'TINYINT': 'NUMBER(3,0)',
      'DOUBLE': 'DOUBLE',
      'FLOAT': 'FLOAT',
      'BOOLEAN': 'BOOLEAN',
      'BINARY': 'BINARY',
      'TIMESTAMP': 'TIMESTAMP_NTZ',
      'DATE': 'DATE'
    };

    let result = sql;
    for (const [hiveType, snowType] of Object.entries(typeMap)) {
      result = result.replace(
        new RegExp(`\\b${hiveType}\\b`, 'gi'),
        snowType
      );
    }

    // Convert complex types
    result = result.replace(/ARRAY\s*<[^>]+>/gi, 'ARRAY');
    result = result.replace(/MAP\s*<[^>]+>/gi, 'OBJECT');
    result = result.replace(/STRUCT\s*<[^>]+>/gi, 'OBJECT');

    return result;
  }

  private formatSQL(sql: string): string {
    return format(sql, {
      language: 'sql',
      keywordCase: 'upper',
      indentStyle: 'standard',
      linesBetweenQueries: 2
    });
  }
}