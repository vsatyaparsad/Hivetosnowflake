import os
import pytest
from pathlib import Path
from sql_converter.__main__ import main, convert_file, convert_directory
from sql_converter import HiveToSnowflakeConverter
import logging

@pytest.fixture
def temp_dir(tmp_path):
    """Create temporary directory with test files"""
    # Create input files
    input_dir = tmp_path / "input"
    input_dir.mkdir()
    
    # Create test SQL files
    (input_dir / "test1.sql").write_text("""
        CREATE TABLE IF NOT EXISTS users (
            id STRING
        ) STORED AS ORC;
    """)
    
    (input_dir / "test2.sql").write_text("""
        INSERT INTO TABLE users
        SELECT id FROM source;
    """)
    
    return tmp_path

def test_single_file_conversion(temp_dir):
    """Test converting a single file"""
    input_file = temp_dir / "input" / "test1.sql"
    output_file = temp_dir / "output.sql"
    
    args = ["--input-file", str(input_file), "--output-file", str(output_file)]
    result = main(args)
    
    assert result == 0
    assert output_file.exists()
    assert "CREATE OR REPLACE TABLE users" in output_file.read_text()

def test_directory_conversion(temp_dir):
    """Test converting a directory of files"""
    input_dir = temp_dir / "input"
    output_dir = temp_dir / "output"
    
    args = ["--input-dir", str(input_dir), "--output-dir", str(output_dir)]
    result = main(args)
    
    assert result == 0
    assert (output_dir / "test1.sql").exists()
    assert (output_dir / "test2.sql").exists()

def test_error_handling(temp_dir):
    """Test error handling for invalid input"""
    input_file = temp_dir / "nonexistent.sql"
    output_file = temp_dir / "output.sql"
    
    args = ["--input-file", str(input_file), "--output-file", str(output_file)]
    result = main(args)
    
    assert result == 1
    assert not output_file.exists()

def test_verbose_logging(temp_dir, caplog):
    """Test verbose logging option"""
    input_file = temp_dir / "input" / "test1.sql"
    output_file = temp_dir / "output.sql"
    
    # Reset logging before test
    logging.getLogger().handlers.clear()
    
    # Configure caplog
    caplog.set_level(logging.DEBUG)
    
    # Create test file
    input_file.parent.mkdir(exist_ok=True)
    input_file.write_text("""
        CREATE TABLE IF NOT EXISTS users (
            id STRING
        ) STORED AS ORC;
    """)
    
    args = [
        "--input-file", str(input_file),
        "--output-file", str(output_file),
        "--verbose"
    ]
    
    with caplog.at_level(logging.DEBUG):
        main(args)
    
    # Print captured logs for debugging
    print("\nCaptured logs:")
    for record in caplog.records:
        print(f"{record.name}: {record.levelname}: {record.message}")
    
    # Check for DEBUG messages
    debug_messages = [
        r for r in caplog.records 
        if r.levelname == "DEBUG"
    ]
    
    # Verify we have DEBUG messages
    assert len(debug_messages) > 0, "No DEBUG messages were logged"
    
    # Verify specific messages
    debug_content = {r.message for r in debug_messages}
    expected_messages = {
        "Debug logging enabled",
        "Starting SQL conversion",
        "Converting statement",
        "Statement converted successfully"
    }
    
    # Check if any expected message is present
    assert any(exp in msg for exp in expected_messages for msg in debug_content), \
        f"Expected one of {expected_messages} in debug messages" 