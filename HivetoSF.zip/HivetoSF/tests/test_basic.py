import pytest
from sql_converter import HiveToSnowflakeConverter

def test_basic_conversion():
    """Test basic SQL conversion"""
    converter = HiveToSnowflakeConverter()
    
    hive_sql = """
    CREATE TABLE IF NOT EXISTS users (
        id STRING
    ) STORED AS ORC;
    """
    
    expected = """
    CREATE OR REPLACE TABLE users (
        id STRING
    );
    """
    
    # Remove whitespace for comparison
    converted = ' '.join(converter.convert_query(hive_sql).split())
    expected = ' '.join(expected.split())
    
    assert converted == expected

def test_complex_conversion():
    """Test complex SQL conversion"""
    converter = HiveToSnowflakeConverter()
    
    hive_sql = """
    INSERT INTO TABLE users
    PARTITION (dt = '2024-03-20')
    SELECT 
        get_json_object(data, '$.id') as user_id,
        unix_timestamp(created_at) as ts
    FROM raw_data;
    """
    
    expected = """
    INSERT INTO users
    SELECT 
        GET_PATH(PARSE_JSON(data), 'id') as user_id,
        DATE_PART(EPOCH_SECOND, created_at) as ts
    FROM raw_data;
    """
    
    # Normalize whitespace for comparison
    converted = ' '.join(converter.convert_query(hive_sql).split())
    expected = ' '.join(expected.split())
    
    assert converted == expected

def test_partition_removal():
    """Test partition clause removal"""
    converter = HiveToSnowflakeConverter()
    
    hive_sql = """
    CREATE TABLE users (
        id STRING,
        name STRING
    )
    PARTITIONED BY (dt STRING)
    CLUSTERED BY (id) INTO 8 BUCKETS;
    """
    
    expected = """
    CREATE TABLE users (
        id STRING,
        name STRING
    );
    """
    
    # Normalize whitespace for comparison
    converted = ' '.join(converter.convert_query(hive_sql).split())
    expected = ' '.join(expected.split())
    
    assert converted == expected

def test_json_conversion():
    """Test JSON function conversion"""
    converter = HiveToSnowflakeConverter()
    
    hive_sql = """
    SELECT 
        get_json_object(data, '$.user.id') as user_id,
        get_json_object(data, '$.user.name') as name
    FROM events;
    """
    
    expected = """
    SELECT 
        GET_PATH(PARSE_JSON(data), 'user:id') as user_id,
        GET_PATH(PARSE_JSON(data), 'user:name') as name
    FROM events;
    """
    
    # Normalize whitespace for comparison
    converted = ' '.join(converter.convert_query(hive_sql).split())
    expected = ' '.join(expected.split())
    
    assert converted == expected 