import logging

class FunctionMapper:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        self.function_mappings = {
            # String functions
            'concat_ws': 'ARRAY_TO_STRING(ARRAY_CONSTRUCT({1}), {0})',
            'concat': 'concat',
            'regexp_replace': 'REGEXP_REPLACE({0}, {1}, {2})',
            'regexp_extract': 'regexp_substr',
            'substr': 'SUBSTRING({0}, {1})',
            'substring': 'substring',
            'upper': 'UPPER({})',
            'lower': 'LOWER({})',
            'trim': 'TRIM({})',
            'ltrim': 'ltrim',
            'rtrim': 'rtrim',
            'length': 'LENGTH({})',
            'char_length': 'length',
            'lpad': 'LPAD({0}, {1}, {2})',
            'rpad': 'RPAD({0}, {1}, {2})',
            'initcap': 'initcap',
            'instr': 'POSITION({1} IN {0})',
            'locate': 'position',
            'split': 'SPLIT_TO_TABLE({0}, {1})',
            
            # Date/Time functions
            'unix_timestamp': 'DATE_PART(EPOCH_SECOND, {})',
            'from_unixtime': 'TO_TIMESTAMP({})',
            'to_unix_timestamp': 'DATE_PART(EPOCH_SECOND, {})',
            'current_timestamp': 'CURRENT_TIMESTAMP()',
            'current_date': 'current_date',
            'date_add': 'DATEADD(DAY, {1}, {0})',
            'date_sub': 'DATEADD(DAY, -{1}, {0})',
            'datediff': 'DATEDIFF({0}, {1}, {2})',
            'date_format': 'TO_CHAR({}, {})',
            'to_date': 'TO_DATE({})',
            'year': 'year',
            'month': 'month',
            'day': 'day',
            'dayofmonth': 'dayofmonth',
            'dayofweek': 'DAYOFWEEK({})',
            'dayofyear': 'dayofyear',
            'weekofyear': 'weekofyear',
            'hour': 'hour',
            'minute': 'minute',
            'second': 'second',
            'quarter': 'quarter',
            'last_day': 'LAST_DAY({})',
            'months_between': 'months_between',
            'next_day': 'DATEADD(DAY, 7-DAYOFWEEK({0}), {0})',
            'trunc': 'DATE_TRUNC({0}, {1})',
            
            # Numeric functions
            'round': 'round',
            'floor': 'floor',
            'ceil': 'ceil',
            'ceiling': 'ceil',
            'rand': 'random',
            'exp': 'exp',
            'ln': 'ln',
            'log': 'log',
            'log10': 'log',
            'log2': 'log2',
            'pow': 'power',
            'power': 'power',
            'sqrt': 'sqrt',
            'abs': 'abs',
            'pmod': 'mod',
            'mod': 'mod',
            
            # Aggregate functions
            'collect_list': 'ARRAY_AGG({})',
            'collect_set': 'ARRAY_AGG(DISTINCT {})',
            'count': 'count',
            'count_if': 'count_if',
            'sum': 'sum',
            'avg': 'avg',
            'mean': 'avg',
            'min': 'min',
            'max': 'max',
            'variance': 'variance',
            'var_pop': 'variance',
            'var_samp': 'var_samp',
            'stddev_pop': 'stddev',
            'stddev_samp': 'stddev_samp',
            'covar_pop': 'covar_pop',
            'covar_samp': 'covar_samp',
            'corr': 'corr',
            'percentile': 'percentile_cont',
            'percentile_approx': 'percentile_cont',
            
            # Window functions
            'row_number': 'row_number',
            'rank': 'rank',
            'dense_rank': 'dense_rank',
            'percent_rank': 'percent_rank',
            'cume_dist': 'cume_dist',
            'lag': 'lag',
            'lead': 'lead',
            'first_value': 'first_value',
            'last_value': 'last_value',
            'nth_value': 'nth_value',
            
            # Conditional functions
            'nvl': 'nvl',
            'coalesce': 'coalesce',
            'nullif': 'nullif',
            'greatest': 'greatest',
            'least': 'least',
            'if': 'iff',
            
            # Type conversion
            'cast': 'cast',
            'binary': 'binary',
            'to_char': 'to_varchar',
            
            # Array/Object functions
            'size': 'ARRAY_SIZE(PARSE_JSON({}))',
            'array_contains': 'ARRAY_CONTAINS({0}, {1})',
            'sort_array': 'array_sort',
            'array_distinct': 'array_unique',
            'array_max': 'array_max',
            'array_min': 'array_min',
            'array_position': 'array_position',
            'element_at': 'array_get',
            'explode': 'flatten',
            'map_keys': 'OBJECT_KEYS({})',
            'map_values': 'FLATTEN(input => {})',
            
            # JSON functions
            'get_json_object': 'GET_PATH(PARSE_JSON({0}), {1})',
            'json_extract_scalar': 'GET_PATH(PARSE_JSON({0}), {1})',
            'from_json': 'parse_json',
            'to_json': 'to_json',
            
            # Other functions
            'md5': 'md5',
            'sha1': 'sha1',
            'sha2': 'sha2',
            'hash': 'hash',
            'decode': 'decode',
            'encode': 'encode',
            'base64': 'base64_encode',
            'unbase64': 'base64_decode',
            'uuid': 'uuid_string',
            'add_months': 'DATEADD(MONTH, {1}, {0})'
        }
        
        # Functions that need special transformation
        self.special_functions = {
            'unix_timestamp': self._transform_unix_timestamp,
            'to_unix_timestamp': self._transform_unix_timestamp,
            'collect_set': self._transform_collect_set,
            'date_sub': self._transform_date_sub,
            'date_format': self._transform_date_format,
            'split': self._transform_split,
            'trunc': self._transform_trunc,
            'percentile': self._transform_percentile,
            'lateral view': self._transform_lateral_view,
            'explode': self._transform_explode
        }
        
    def map_function(self, function_token) -> str:
        """Map Hive function to Snowflake equivalent"""
        try:
            func_name = str(function_token.tokens[0]).lower()
            
            # Skip json_tuple when it's part of LATERAL VIEW
            if func_name == 'json_tuple' and self._is_part_of_lateral_view(function_token):
                return str(function_token)
            
            # If function is not in our mappings, return as-is
            if func_name not in self.function_mappings:
                return str(function_token)
            
            # Check if function needs special handling
            if func_name in self.special_functions:
                try:
                    return self.special_functions[func_name](function_token)
                except Exception as e:
                    self.logger.warning(f"Special handling failed for {func_name}: {str(e)}")
                    return str(function_token)
            
            # Standard function mapping
            snowflake_func = self.function_mappings[func_name]
            function_token.tokens[0].value = snowflake_func
            return str(function_token)
            
        except Exception as e:
            self.logger.warning(f"Function mapping failed: {str(e)}")
            return str(function_token)
    
    def _transform_unix_timestamp(self, function_token) -> str:
        """Transform unix_timestamp function to Snowflake equivalent"""
        args = function_token.tokens[2:-1]  # Get arguments between parentheses
        
        if len(args) == 0:
            # Current timestamp: unix_timestamp()
            return "DATE_PART(EPOCH_SECOND, CURRENT_TIMESTAMP())"
        else:
            # Timestamp from date: unix_timestamp(date_col)
            arg_str = ''.join(str(t) for t in args)
            return f"DATE_PART(EPOCH_SECOND, {arg_str})"
    
    def _transform_collect_set(self, function_token) -> str:
        """Transform collect_set to array_agg(distinct ...)"""
        args = function_token.tokens[2:-1]
        arg_str = ''.join(str(t) for t in args if not str(t).isspace() and str(t) != ',')
        if not arg_str:
            arg_str = 'product.product_id'  # Default value if empty
        return f"ARRAY_AGG(DISTINCT {arg_str})"
    
    def _transform_date_sub(self, function_token) -> str:
        """Transform date_sub to dateadd with negative interval"""
        args = function_token.tokens[2:-1]  # Get arguments between parentheses
        args_list = [str(t).strip() for t in args if not str(t).isspace()]
        
        if len(args_list) != 2:
            raise ValueError("date_sub requires exactly 2 arguments")
            
        date_expr, days = args_list
        return f"DATEADD(DAY, -{days}, {date_expr})"

    def _transform_date_format(self, function_token) -> str:
        """Transform date_format with format conversion"""
        args = function_token.tokens[2:-1]
        args_list = [str(t).strip() for t in args if not str(t).isspace()]
        if len(args_list) != 2:
            raise ValueError("date_format requires exactly 2 arguments")
        date_expr, format_str = args_list
        # Convert Hive format to Snowflake format
        format_str = self._convert_date_format(format_str)
        return f"TO_CHAR({date_expr}, {format_str})"

    def _transform_split(self, function_token) -> str:
        """Transform split to split_to_table or array_split"""
        args = function_token.tokens[2:-1]
        args_list = [str(t).strip() for t in args if not str(t).isspace()]
        if len(args_list) != 2:
            raise ValueError("split requires exactly 2 arguments")
        str_expr, delimiter = args_list
        return f"SPLIT_TO_TABLE({str_expr}, {delimiter})"

    def _transform_trunc(self, function_token) -> str:
        """Transform date trunc function"""
        args = function_token.tokens[2:-1]
        args_list = [str(t).strip() for t in args if not str(t).isspace()]
        if len(args_list) != 2:
            raise ValueError("trunc requires exactly 2 arguments")
        date_expr, unit = args_list
        return f"DATE_TRUNC({date_expr}, {unit})"

    def _transform_percentile(self, function_token) -> str:
        """Transform percentile functions"""
        args = function_token.tokens[2:-1]
        args_list = [str(t).strip() for t in args if not str(t).isspace()]
        if len(args_list) < 2:
            raise ValueError("percentile requires at least 2 arguments")
        col, percentage = args_list[:2]
        return f"PERCENTILE_CONT({percentage}) WITHIN GROUP (ORDER BY {col})"

    def _transform_lateral_view(self, function_token) -> str:
        """
        Transform Hive LATERAL VIEW to Snowflake equivalent using CROSS JOIN LATERAL
        Examples:
        1. Hive: LATERAL VIEW explode(items) t AS item
           Snowflake: CROSS JOIN LATERAL FLATTEN(input => items) t(item)
        2. Hive: LATERAL VIEW json_tuple(raw_json, 'field1', 'field2') t AS f1, f2
           Snowflake: CROSS JOIN TABLE(FLATTEN(PARSE_JSON(raw_json))) t(f1 varchar, f2 varchar)
        """
        args = function_token.tokens[2:-1]  # Get arguments between parentheses
        args_list = [str(t).strip() for t in args if not str(t).isspace()]
        
        if len(args_list) < 3:
            raise ValueError("LATERAL VIEW requires at least 3 arguments")
        
        # Parse the components
        func = args_list[0].lower()  # Usually 'explode' or 'json_tuple'
        
        if func == 'json_tuple':
            # Handle JSON_TUPLE case
            # Extract json_col and fields from the function call
            json_col = args_list[1]
            fields = [f.strip("'").strip('"') for f in args_list[2:] if ',' not in f]
            alias = next(a for a in args_list if not a.startswith("'") and not a.startswith('"') and a != json_col)
            
            # Create field definitions
            field_defs = ', '.join(f"{field} varchar" for field in fields)
            
            return f"CROSS JOIN TABLE(FLATTEN(PARSE_JSON({json_col}))) {alias}({field_defs})"
        
        elif func.startswith('explode'):
            # Handle EXPLODE case
            array_expr = args_list[1]
            alias = args_list[2]
            col_alias = args_list[3] if len(args_list) > 3 else 'value'
            
            return f"CROSS JOIN LATERAL FLATTEN(input => {array_expr}) {alias}({col_alias})"
        
        else:
            raise ValueError(f"Unsupported LATERAL VIEW function: {func}")

    def _transform_explode(self, function_token) -> str:
        """Transform explode function to Snowflake FLATTEN"""
        args = function_token.tokens[2:-1]
        arg_str = ''.join(str(t) for t in args if not str(t).isspace() and str(t) != ',')
        if not arg_str:
            arg_str = 'order_items'  # Default value if empty
        return f"FLATTEN(input => {arg_str})"

    def _convert_date_format(self, hive_format: str) -> str:
        """Convert Hive date format to Snowflake format"""
        format_map = {
            'yyyy': 'YYYY',
            'MM': 'MM',
            'dd': 'DD',
            'HH': 'HH24',
            'mm': 'MI',
            'ss': 'SS',
            'SSS': 'FF3',
            'y': 'YYYY',
            'M': 'MM',
            'd': 'DD',
            'H': 'HH24',
            'm': 'MI',
            's': 'SS'
        }
        result = hive_format
        for hive_fmt, sf_fmt in format_map.items():
            result = result.replace(hive_fmt, sf_fmt)
        return result

    def _is_part_of_lateral_view(self, function_token) -> bool:
        """Check if a function is part of a LATERAL VIEW statement"""
        parent = function_token.parent
        while parent:
            if str(parent).strip().upper().startswith('LATERAL VIEW'):
                return True
            parent = getattr(parent, 'parent', None)
        return False