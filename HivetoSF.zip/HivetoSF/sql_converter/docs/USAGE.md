# How to Run Hive to Snowflake SQL Converter

## 1. Command Line Interface (CLI)

### Basic Usage

# Create a file with your Hive SQL (e.g., hive_query.sql)
echo "
CREATE TABLE IF NOT EXISTS users (
    user_id STRING,
    name STRING
) STORED AS ORC;
" > hive_query.sql

# Run the converter
python -m sql_converter hive_query.sql -o snowflake_query.sql

### Batch Processing

python -m sql_converter --input-dir ./hive_queries --output-dir ./snowflake_queries

### Single File Conversion

# Convert a single file
python -m sql_converter --input-file query.sql --output-file converted.sql

# With verbose logging
python -m sql_converter -i query.sql -o converted.sql --verbose

## 2. Python API Usage

### Single Query Conversion

```python
from sql_converter import HiveToSnowflakeConverter

# Initialize converter
converter = HiveToSnowflakeConverter()

# Convert a single query
hive_sql = """
CREATE TABLE IF NOT EXISTS users (
    user_id STRING,
    name STRING
) STORED AS ORC;
"""

try:
    snowflake_sql = converter.convert_query(hive_sql)
    print(snowflake_sql)
except ConversionError as e:
    print(f"Error converting query: {e}")
```

### Multiple Queries

```python
# Convert multiple queries
hive_queries = [
    """
    CREATE TABLE IF NOT EXISTS table1 (id STRING);
    """,
    """
    INSERT INTO TABLE table1 SELECT * FROM source;
    """
]

for query in hive_queries:
    try:
        snowflake_sql = converter.convert_query(query)
        print(snowflake_sql)
    except ConversionError as e:
        print(f"Error converting query: {e}")
```

### File Processing

```python
# Convert SQL from file
def convert_file(input_file, output_file):
    converter = HiveToSnowflakeConverter()
    
    with open(input_file, 'r') as f:
        hive_sql = f.read()
    
    try:
        snowflake_sql = converter.convert_query(hive_sql)
        with open(output_file, 'w') as f:
            f.write(snowflake_sql)
        print(f"Successfully converted {input_file} to {output_file}")
    except ConversionError as e:
        print(f"Error converting {input_file}: {e}")

# Usage
convert_file('path/to/hive_query.sql', 'path/to/snowflake_query.sql')
```

## 3. Advanced Usage

### With Logging

```python
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='conversion.log'
)

converter = HiveToSnowflakeConverter()
```

### With Custom Error Handling

```python
from sql_converter.exceptions import (
    ConversionError,
    TypeMappingError,
    FunctionMappingError,
    SyntaxError
)

try:
    snowflake_sql = converter.convert_query(hive_sql)
except TypeMappingError as e:
    print(f"Type mapping error: {e}")
except FunctionMappingError as e:
    print(f"Function mapping error: {e}")
except SyntaxError as e:
    print(f"Syntax error: {e}")
except ConversionError as e:
    print(f"General conversion error: {e}")
```

### With Progress Tracking

```python
import os
from tqdm import tqdm

def convert_directory(input_dir, output_dir):
    converter = HiveToSnowflakeConverter()
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get all SQL files
    sql_files = [f for f in os.listdir(input_dir) if f.endswith('.sql')]
    
    # Process files with progress bar
    for file in tqdm(sql_files, desc="Converting SQL files"):
        input_path = os.path.join(input_dir, file)
        output_path = os.path.join(output_dir, file)
        
        try:
            with open(input_path, 'r') as f:
                hive_sql = f.read()
            
            snowflake_sql = converter.convert_query(hive_sql)
            
            with open(output_path, 'w') as f:
                f.write(snowflake_sql)
                
        except Exception as e:
            print(f"Error converting {file}: {e}")

# Usage
convert_directory('./hive_queries', './snowflake_queries')
```

## 4. Command Line Options

```bash
python -m sql_converter --help

Options:
  --input-file TEXT     Input Hive SQL file
  --output-file TEXT    Output Snowflake SQL file
  --input-dir TEXT      Input directory containing Hive SQL files
  --output-dir TEXT     Output directory for Snowflake SQL files
  --log-level TEXT      Logging level (DEBUG, INFO, WARNING, ERROR)
  --verbose            Enable verbose output
  --help              Show this help message
```

## 5. Environment Setup

1. Create virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install package:
```bash
pip install hive-to-snowflake-converter
```

3. Verify installation:
```python
from sql_converter import HiveToSnowflakeConverter
converter = HiveToSnowflakeConverter()
print("Installation successful!")
```

Would you like me to add any other usage examples or explain any part in more detail?
