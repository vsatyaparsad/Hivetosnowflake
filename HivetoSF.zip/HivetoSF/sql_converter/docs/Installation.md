I'll create the INSTALLATION.md file in the correct location:

```markdown:sql_converter/docs/INSTALLATION.md
# Installation Guide for Hive to Snowflake SQL Converter

## Prerequisites

### Required
- Python 3.7 or higher
- pip (Python package installer)

### Optional
- Git (for source installation)
- virtualenv or venv (recommended)

## Installation Methods

### 1. Using pip (Recommended)

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On Unix or MacOS:
source venv/bin/activate

# Install package
pip install hive-to-snowflake-converter
```

### 2. From Source

```bash
# Clone repository
git clone https://github.com/yourusername/hive-to-snowflake-converter.git
cd hive-to-snowflake-converter

# Install in development mode
pip install -e .
```

## Dependencies

The following dependencies will be automatically installed:

```text
# requirements.txt
sqlglot>=5.1.0
```

For development, additional dependencies are required:

```text
# requirements-dev.txt
pytest>=7.0.0
black>=22.0.0
flake8>=4.0.0
mypy>=0.950
```

## Quick Start

```python
# Verify installation
from sql_converter import HiveToSnowflakeConverter

# Initialize converter
converter = HiveToSnowflakeConverter()

# Test conversion
hive_sql = """
CREATE TABLE IF NOT EXISTS example (
    id STRING
) STORED AS ORC;
"""

snowflake_sql = converter.convert_query(hive_sql)
print(snowflake_sql)
```

## Project Structure

```
sql_converter/
├── __init__.py           # Package initialization
├── converter.py          # Main conversion logic
├── function_mapper.py    # Function mapping definitions
├── type_mapper.py        # Data type mappings
├── query_optimizer.py    # Query optimization
├── exceptions.py         # Custom exceptions
└── docs/                 # Documentation
    ├── README.md
    ├── INSTALLATION.md
    └── ...
```

## Troubleshooting

### Common Issues

1. **Import Error**
   ```
   ImportError: No module named 'sqlglot'
   ```
   Solution:
   ```bash
   pip install sqlglot
   ```

2. **Version Conflicts**
   Solution:
   ```bash
   pip install --upgrade hive-to-snowflake-converter
   ```

3. **Permission Issues**
   Solution:
   ```bash
   pip install --user hive-to-snowflake-converter
   ```

## Development Setup

1. Install development dependencies:
   ```bash
   pip install -r requirements-dev.txt
   ```

2. Run tests:
   ```bash
   pytest
   ```

3. Check code style:
   ```bash
   flake8 sql_converter
   black sql_converter
   ```

4. Run type checker:
   ```bash
   mypy sql_converter
   ```

## Uninstallation

```bash
# Remove package
pip uninstall hive-to-snowflake-converter

# Optional: remove virtual environment
deactivate
rm -rf venv
```

## Support

For issues and feature requests:
- Create an issue on GitHub
- Contact: support@example.com

## License

This project is licensed under the MIT License - see the LICENSE file for details.
```

This installation guide provides:
1. Clear prerequisites
2. Multiple installation methods
3. Dependency information
4. Quick start guide
5. Project structure
6. Troubleshooting steps
7. Development setup
8. Uninstallation instructions

Would you like me to add or modify any section?
