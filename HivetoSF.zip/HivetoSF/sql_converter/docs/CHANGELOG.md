# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2024-03-XX

### Added
- Initial release with core functionality
- Support for converting Hive SQL to Snowflake SQL
- Function mappings for date, string, JSON, and array operations
- Syntax conversions for CREATE TABLE, INSERT statements
- Error handling and logging
- Documentation and examples

### Changed
- N/A (Initial release)

### Fixed
- N/A (Initial release) 