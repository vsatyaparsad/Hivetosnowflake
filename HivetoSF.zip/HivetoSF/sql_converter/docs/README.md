# Hive to Snowflake SQL Converter

A Python tool to convert Hive SQL queries to Snowflake SQL syntax.

## Features

### Syntax Conversions
- CREATE TABLE IF NOT EXISTS → CREATE OR REPLACE TABLE
- INSERT OVERWRITE INTO → INSERT INTO
- PARTITIONED BY removal
- CLUSTERED BY and SORTED BY removal
- STORED AS removal
- TBLPROPERTIES removal
- LOCATION clause removal

### Function Mappings

1. Timestamp Functions:
   - unix_timestamp() → DATE_PART(EPOCH_SECOND, ...)
   - from_unixtime() → TO_TIMESTAMP()
   - current_timestamp() → CURRENT_TIMESTAMP()
   - to_date() → TO_DATE()
   - date_format() → TO_CHAR()

2. String Functions:
   - concat_ws() → ARRAY_TO_STRING(ARRAY_CONSTRUCT())
   - instr() → POSITION()
   - substr() → SUBSTRING()
   - regexp_replace() → REGEXP_REPLACE()
   - split() → SPLIT_TO_TABLE()
   - length() → LENGTH()
   - trim() → TRIM()
   - upper()/lower() → UPPER()/LOWER()
   - lpad()/rpad() → LPAD()/RPAD()

3. JSON Functions:
   - get_json_object() → GET_PATH(PARSE_JSON())
   - json_tuple() → PARSE_JSON():[field]
   - Complex JSON paths handling

4. Array/Map Functions:
   - collect_list() → ARRAY_AGG()
   - collect_set() → ARRAY_AGG(DISTINCT)
   - explode() → LATERAL FLATTEN()
   - posexplode() → FLATTEN() with index
   - map() → OBJECT_CONSTRUCT()
   - str_to_map() → PARSE_JSON(OBJECT_CONSTRUCT_KEEP_NULL())

5. Date Functions:
   - add_months() → DATEADD(MONTH, ...)
   - last_day() → Custom date calculation
   - datediff() → DATEDIFF()

6. Window Functions:
   - ROWS BETWEEN syntax adjustments
   - RANGE BETWEEN conversions
   - Proper handling of window frames

### Error Handling
- ConversionError: Base exception for all conversion errors
- TypeMappingError: For unsupported type conversions
- FunctionMappingError: For unsupported function mappings
- SyntaxError: For invalid SQL syntax 