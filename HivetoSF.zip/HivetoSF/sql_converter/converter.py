from typing import Dict, Optional, List
import sqlglot
from sqlglot import exp
from sqlglot.dialects import hive, snowflake
from .exceptions import ConversionError
import logging
import re

class HiveToSnowflakeConverter:
    def __init__(self):
        self.logger = logging.getLogger('sql_converter.converter')
        
    def convert_query(self, hive_query: str) -> str:
        """Convert Hive SQL queries to Snowflake SQL"""
        try:
            self.logger.debug("Starting SQL conversion")
            self.logger.debug(f"Input query (first 100 chars): {hive_query[:100]}...")
            
            statements = self._split_statements(hive_query)
            self.logger.debug(f"Split into {len(statements)} statements")
            
            converted_statements = []
            for i, stmt in enumerate(statements, 1):
                self.logger.debug(f"Processing statement {i}/{len(statements)}")
                
                if not stmt.strip() or stmt.strip().startswith('--'):
                    self.logger.debug("Skipping comment or empty statement")
                    converted_statements.append(stmt)
                    continue
                
                if stmt.strip().upper().startswith('SET '):
                    self.logger.debug("Skipping SET command")
                    continue
                
                self.logger.debug("Converting statement")
                converted = self._handle_special_cases(stmt)
                converted_statements.append(converted)
                self.logger.debug("Statement converted successfully")
            
            result = '\n\n'.join(converted_statements)
            self.logger.debug("All statements combined successfully")
            return result
            
        except Exception as e:
            self.logger.error(f"Conversion error: {str(e)}")
            raise ConversionError(f"Failed to convert query: {str(e)}")
    
    def _handle_special_cases(self, sql: str) -> str:
        """Handle Hive constructs not supported by sqlglot"""
        # Remove Hive hints
        sql = re.sub(r'/\*\+[^*]*\*/', '', sql)
        
        # Convert CREATE TABLE statements
        sql = re.sub(
            r'CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+(\w+)',
            r'CREATE OR REPLACE TABLE \1',
            sql,
            flags=re.IGNORECASE
        )
        
        # Convert INSERT statements and remove partitioning
        sql = re.sub(r'INSERT\s+INTO\s+TABLE\s+', r'INSERT INTO ', sql, flags=re.IGNORECASE)
        sql = re.sub(r'INSERT\s+OVERWRITE\s+(?:INTO\s+)?TABLE\s+', r'INSERT INTO ', sql, flags=re.IGNORECASE)
        sql = re.sub(r'\s*PARTITION\s*\([^)]+\)', '', sql, flags=re.IGNORECASE)
        
        # Remove partitioning and clustering
        sql = re.sub(r'\s*PARTITIONED\s+BY\s*\([^)]+\)', '', sql, flags=re.IGNORECASE)
        sql = re.sub(r'\s*CLUSTERED\s+BY\s*\([^)]+\)\s+INTO\s+\d+\s+BUCKETS', '', sql, flags=re.IGNORECASE)
        
        # Convert JSON functions
        sql = re.sub(
            r'get_json_object\(([^,]+),\s*\'\$\.([^\']+)\'\)',
            lambda m: f"GET_PATH(PARSE_JSON({m.group(1)}), '{m.group(2).replace('.', ':')}')",
            sql,
            flags=re.IGNORECASE
        )
        
        # Convert timestamp functions
        sql = re.sub(
            r'unix_timestamp\(([^)]+)\)',
            r'DATE_PART(EPOCH_SECOND, \1)',
            sql,
            flags=re.IGNORECASE
        )
        
        # Remove storage format
        sql = re.sub(r'\s*STORED\s+AS\s+\w+', '', sql, flags=re.IGNORECASE)
        
        # Clean up semicolons
        sql = re.sub(r'\s*;\s*$', ';', sql)
        
        return sql.strip()
    
    def _handle_basic_conversions(self, sql: str) -> str:
        """Handle basic syntax conversions"""
        # Remove partitioning and clustering
        sql = re.sub(r'PARTITIONED\s+BY\s*\([^)]+\)', '', sql, flags=re.IGNORECASE)
        sql = re.sub(r'CLUSTERED\s+BY\s*\([^)]+\)\s+INTO\s+\d+\s+BUCKETS', '', sql, flags=re.IGNORECASE)
        
        # Convert array functions
        sql = re.sub(r'ARRAY\s*<\s*([^>]+)\s*>', r'ARRAY', sql, flags=re.IGNORECASE)
        sql = re.sub(r'COLLECT_SET\(([^)]+)\)', r'ARRAY_AGG(DISTINCT \1)', sql, flags=re.IGNORECASE)
        sql = re.sub(r'COLLECT_LIST\(([^)]+)\)', r'ARRAY_AGG(\1)', sql, flags=re.IGNORECASE)
        
        # Convert explode functions
        sql = re.sub(
            r'posexplode\(([^)]+)\)\s+AS\s+(\w+)',
            r'LATERAL FLATTEN(input => \1) f(index, \2)',
            sql,
            flags=re.IGNORECASE
        )
        sql = re.sub(
            r'explode\(([^)]+)\)\s+AS\s+(\w+)',
            r'LATERAL FLATTEN(input => \1) AS \2',
            sql,
            flags=re.IGNORECASE
        )
        
        # Remove storage formats and hints
        sql = re.sub(r'\s+DISTRIBUTE\s+BY\s+[^;]+', '', sql, flags=re.IGNORECASE)
        sql = re.sub(r'\s+SORT\s+BY\s+[^;]+', '', sql, flags=re.IGNORECASE)
        sql = re.sub(r'\s+CLUSTER\s+BY\s+[^;]+', '', sql, flags=re.IGNORECASE)
        
        return sql
    
    def _handle_transform(self, match: re.Match) -> str:
        """Handle Hive TRANSFORM function conversion"""
        args = match.group(1).split(',')
        if len(args) == 1:
            return f"ARRAY_AGG({args[0]})"
        else:
            # For complex transformations, use ARRAY_AGG with a CASE statement
            return f"ARRAY_AGG(CASE WHEN {args[1]} THEN {args[0]} END)"
    
    def _convert_json_tuple(self, sql: str) -> str:
        """Convert Hive JSON_TUPLE to Snowflake JSON parsing"""
        pattern = r'LATERAL\s+VIEW\s+JSON_TUPLE\(([^,]+),\s*([^)]+)\)\s+(\w+)\s+AS\s+([^;\n]+)'
        
        def replace_json_tuple(match):
            json_col, fields, alias, field_names = match.groups()
            fields = [f.strip().strip("'\"") for f in fields.split(',')]
            field_names = [f.strip() for f in field_names.split(',')]
            
            # Use GET_PATH for nested JSON paths
            selects = []
            for field, name in zip(fields, field_names):
                if '.' in field:
                    # Handle nested paths
                    path = field.replace('.', ':')
                    selects.append(f"GET_PATH(PARSE_JSON({json_col}), '{path}')::{name}")
                else:
                    selects.append(f"PARSE_JSON({json_col}):{field}::{name}")
            
            return f"CROSS JOIN LATERAL (SELECT {', '.join(selects)})"
        
        return re.sub(pattern, replace_json_tuple, sql, flags=re.IGNORECASE)
    
    def _split_statements(self, sql: str) -> List[str]:
        """Split SQL into individual statements"""
        statements = []
        current_stmt = []
        
        for line in sql.splitlines():
            if line.strip().startswith('--'):
                if current_stmt:
                    statements.append('\n'.join(current_stmt))
                    current_stmt = []
                statements.append(line)
            else:
                current_stmt.append(line)
                if ';' in line:
                    statements.append('\n'.join(current_stmt))
                    current_stmt = []
        
        if current_stmt:
            statements.append('\n'.join(current_stmt))
        
        return statements 