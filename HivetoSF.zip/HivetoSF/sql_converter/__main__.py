#!/usr/bin/env python3

import argparse
import logging
import os
import sys
from typing import List
from pathlib import Path

from .converter import HiveToSnowflakeConverter
from .exceptions import ConversionError

def setup_logging(level: str = "INFO", verbose: bool = False) -> None:
    """Configure logging"""
    # Reset logging configuration
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    
    # Set base configuration
    log_level = logging.DEBUG if verbose else getattr(logging, level.upper(), logging.INFO)
    
    # Create console handler
    console = logging.StreamHandler()
    console.setLevel(log_level)
    
    # Create formatter
    if verbose:
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    else:
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    console.setFormatter(formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.addHandler(console)
    
    # Configure package loggers
    for name in ['sql_converter', 'sql_converter.converter']:
        logger = logging.getLogger(name)
        logger.setLevel(log_level)
        # Don't add handler to prevent duplicate messages
        logger.propagate = True
    
    if verbose:
        logging.getLogger('sql_converter').debug("Debug logging enabled")

def convert_file(input_file: str, output_file: str, converter: HiveToSnowflakeConverter) -> bool:
    """Convert a single SQL file"""
    try:
        with open(input_file, 'r') as f:
            hive_sql = f.read()
        
        snowflake_sql = converter.convert_query(hive_sql)
        
        with open(output_file, 'w') as f:
            f.write(snowflake_sql)
        
        logging.info(f"Successfully converted {input_file} to {output_file}")
        return True
        
    except Exception as e:
        logging.error(f"Error converting {input_file}: {e}")
        return False

def convert_directory(input_dir: str, output_dir: str, converter: HiveToSnowflakeConverter) -> tuple[int, int]:
    """Convert all SQL files in a directory"""
    success_count = 0
    total_count = 0
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Process all SQL files
    for root, _, files in os.walk(input_dir):
        for file in files:
            if not file.endswith('.sql'):
                continue
                
            total_count += 1
            input_path = os.path.join(root, file)
            
            # Maintain directory structure in output
            rel_path = os.path.relpath(root, input_dir)
            output_path = os.path.join(output_dir, rel_path, file)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            if convert_file(input_path, output_path, converter):
                success_count += 1
    
    return success_count, total_count

def main(args: List[str] = None) -> int:
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Convert Hive SQL to Snowflake SQL')
    
    # Command arguments
    parser.add_argument('--input-file', '-i', help='Input Hive SQL file')
    parser.add_argument('--output-file', '-o', help='Output Snowflake SQL file')
    parser.add_argument('--input-dir', '-d', help='Input directory containing Hive SQL files')
    parser.add_argument('--output-dir', '-D', help='Output directory for Snowflake SQL files')
    
    # Optional arguments
    parser.add_argument('--log-level', default='INFO', 
                       choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='Logging level')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Enable verbose output')
    
    args = parser.parse_args(args)
    
    # Setup logging
    setup_logging(args.log_level, args.verbose)
    
    # Initialize converter
    converter = HiveToSnowflakeConverter()
    
    try:
        if args.input_file:
            # Single file conversion
            if not args.output_file:
                parser.error("--output-file is required when using --input-file")
            
            success = convert_file(args.input_file, args.output_file, converter)
            return 0 if success else 1
            
        elif args.input_dir:
            # Directory conversion
            if not args.output_dir:
                parser.error("--output-dir is required when using --input-dir")
            
            success_count, total_count = convert_directory(args.input_dir, args.output_dir, converter)
            logging.info(f"Converted {success_count} of {total_count} files successfully")
            return 0 if success_count == total_count else 1
            
        else:
            parser.error("Either --input-file or --input-dir is required")
            
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return 1

if __name__ == '__main__':
    sys.exit(main()) 