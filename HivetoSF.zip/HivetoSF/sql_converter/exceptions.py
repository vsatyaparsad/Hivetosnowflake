class ConversionError(Exception):
    """Exception raised for errors during SQL conversion"""
    pass

class TypeMappingError(ConversionError):
    """Raised when a Hive type cannot be mapped to Snowflake"""
    pass

class FunctionMappingError(ConversionError):
    """Raised when a Hive function cannot be mapped to Snowflake"""
    pass

class SyntaxError(ConversionError):
    """Raised when the input SQL has invalid syntax"""
    pass 