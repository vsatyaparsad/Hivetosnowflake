from typing import Dict

class TypeMapper:
    def __init__(self):
        self.type_mappings: Dict[str, str] = {
            'STRING': 'VARCHAR',
            'VARCHAR': 'VARCHAR',
            'CHAR': 'CHAR',
            'TINYINT': 'SMALLINT',
            'SMALLINT': 'SMALLINT',
            'INT': 'INTEGER',
            'BIGINT': 'BIGINT',
            'FLOAT': 'FLOAT',
            'DOUBLE': 'DOUBLE',
            'DECIMAL': 'DECIMAL',
            'BOOLEAN': 'BOOLEAN',
            'TIMESTAMP': 'TIMESTAMP',
            'DATE': 'DATE',
            'BINARY': 'BINARY',
            'ARRAY': 'ARRAY',
            'MAP': 'OBJECT',
            'STRUCT': 'OBJECT'
        }
    
    def map_type(self, hive_type: str) -> str:
        """
        Map Hive data type to Snowflake equivalent
        """
        base_type = hive_type.split('<')[0].upper()
        if base_type not in self.type_mappings:
            raise ValueError(f"Unsupported Hive type: {hive_type}")
            
        mapped_type = self.type_mappings[base_type]
        
        # Handle parameterized types (e.g., DECIMAL(10,2))
        if '<' in hive_type:
            params = hive_type[hive_type.find('<')+1:hive_type.find('>')]
            mapped_type = f"{mapped_type}({params})"
            
        return mapped_type 