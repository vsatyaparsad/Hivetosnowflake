#!/bin/bash

echo "Setting up SQL Converter environment..."

# Create directories
mkdir -p hive_queries snowflake_queries sql_converter/docs/conversions

# Create example Hive SQL files
echo "Creating example Hive SQL files..."

# User Sessions example
cat > hive_queries/user_sessions.hql << 'EOF'
CREATE TABLE IF NOT EXISTS user_sessions (
    user_id STRING,
    session_id INT,
    session_start TIMESTAMP,
    session_end TIMESTAMP
)
PARTITIONED BY (dt STRING)
CLUSTERED BY (user_id) INTO 8 BUCKETS;

INSERT INTO TABLE user_sessions
PARTITION (dt = '2024-03-20')
SELECT 
    user_id,
    session_id,
    from_unixtime(unix_timestamp(event_time)) as session_start,
    from_unixtime(unix_timestamp(end_time)) as session_end
FROM events;
EOF

# Complex query example
cat > hive_queries/complex.hql << 'EOF'
-- JSON and Array Processing
SELECT 
    user_id,
    get_json_object(data, '$.user.preferences') as prefs,
    collect_list(tag) as tags,
    collect_set(category) as unique_categories
FROM (
    SELECT 
        user_id,
        data,
        explode(tags) as tag,
        category
    FROM user_data
    LATERAL VIEW json_tuple(raw_json, 'user_id', 'data') jt 
    AS user_id, data
) t
GROUP BY user_id, data;
EOF

# Make script executable
chmod +x examples/convert_queries.py

# Run conversion
echo "Running SQL conversion..."
python examples/convert_queries.py

echo "Setup complete! Check the following directories:"
echo "- hive_queries: Original Hive SQL files"
echo "- snowflake_queries: Converted Snowflake SQL files"
echo "- sql_converter/docs/conversions: Conversion documentation" 