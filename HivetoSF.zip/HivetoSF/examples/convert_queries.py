#!/usr/bin/env python3

import os
import sys
import logging
import difflib
from pathlib import Path
from typing import Dict, List, Tuple
from datetime import datetime
from sql_converter import HiveToSnowflakeConverter

def setup_logging():
    """Configure logging"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

def analyze_query_complexity(sql: str) -> Dict[str, int]:
    """Analyze SQL complexity"""
    metrics = {
        'joins': sql.lower().count('join'),
        'subqueries': sql.count('(SELECT'),
        'window_functions': sql.lower().count('over ('),
        'aggregations': sum(1 for agg in ['COUNT(', 'SUM(', 'AVG(', 'MAX(', 'MIN('] 
                          if agg in sql.upper()),
        'case_statements': sql.lower().count('case when'),
    }
    return metrics

def generate_diff(hive_sql: str, snowflake_sql: str) -> str:
    """Generate a readable diff between Hive and Snowflake SQL"""
    diff = difflib.unified_diff(
        hive_sql.splitlines(),
        snowflake_sql.splitlines(),
        fromfile='Hive SQL',
        tofile='Snowflake SQL',
        lineterm=''
    )
    return '\n'.join(diff)

def create_conversion_doc(hive_sql: str, snowflake_sql: str, filename: str) -> str:
    """Create enhanced markdown documentation for SQL conversion"""
    query_type = filename.replace('.hql', '').replace('.sql', '').title()
    complexity = analyze_query_complexity(hive_sql)
    
    doc = f"""# {query_type} SQL Conversion Details

Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Query Complexity Analysis
- Joins: {complexity['joins']}
- Subqueries: {complexity['subqueries']}
- Window Functions: {complexity['window_functions']}
- Aggregations: {complexity['aggregations']}
- Case Statements: {complexity['case_statements']}

## Original Hive Query
```sql
{hive_sql.strip()}
```

## Converted Snowflake Query
```sql
{snowflake_sql.strip()}
```

## Detailed Changes
### SQL Diff
```diff
{generate_diff(hive_sql, snowflake_sql)}
```

### Structural Changes
"""
    
    changes = []
    
    # Table creation changes
    if 'CREATE TABLE' in hive_sql:
        changes.append("\n#### Table Definition Changes")
        if 'PARTITIONED BY' in hive_sql:
            changes.append("- Removed PARTITIONED BY clause")
            changes.append("  - Snowflake Alternative: Use clustering keys or micro-partitions")
        if 'CLUSTERED BY' in hive_sql:
            changes.append("- Removed CLUSTERED BY clause")
            changes.append("  - Snowflake Alternative: `ALTER TABLE ... CLUSTER BY`")
        if 'STORED AS' in hive_sql:
            changes.append("- Removed storage format specifications")
            changes.append("  - Snowflake handles storage optimization automatically")
    
    # Data manipulation changes
    if 'INSERT' in hive_sql:
        changes.append("\n#### Data Manipulation Changes")
        if 'INSERT INTO TABLE' in hive_sql:
            changes.append("- Simplified INSERT syntax")
        if 'PARTITION' in hive_sql:
            changes.append("- Removed explicit partitioning")
            changes.append("  - Snowflake uses automatic micro-partitioning")
    
    # Function conversions
    function_changes = []
    if any(f in hive_sql.lower() for f in ['get_json_object', 'json_tuple', 'unix_timestamp']):
        function_changes.append("\n#### Function Conversions")
        if 'get_json_object' in hive_sql:
            function_changes.append("- JSON Path Access:")
            function_changes.append("  - Hive: `get_json_object(col, '$.path')`")
            function_changes.append("  - Snowflake: `GET_PATH(PARSE_JSON(col), 'path')`")
        if 'json_tuple' in hive_sql:
            function_changes.append("- JSON Extraction:")
            function_changes.append("  - Hive: `json_tuple(col, 'field')`")
            function_changes.append("  - Snowflake: `PARSE_JSON(col):field`")
        if 'unix_timestamp' in hive_sql:
            function_changes.append("- Timestamp Handling:")
            function_changes.append("  - Hive: `unix_timestamp(col)`")
            function_changes.append("  - Snowflake: `DATE_PART(EPOCH_SECOND, col)`")
    
    changes.extend(function_changes)
    
    # Performance recommendations
    doc += '\n'.join(changes)
    doc += "\n\n## Performance Optimization Guidelines"
    doc += "\n### Snowflake Best Practices"
    doc += "\n1. Clustering Recommendations:"
    doc += "\n   - Consider clustering on frequently filtered columns"
    doc += "\n   - Monitor clustering using `SYSTEM$CLUSTERING_INFORMATION`"
    
    doc += "\n\n2. Query Optimization:"
    doc += "\n   - Use appropriate column types"
    doc += "\n   - Leverage Snowflake's automatic query optimization"
    doc += "\n   - Monitor query performance with `QUERY_HISTORY`"
    
    doc += "\n\n3. Resource Optimization:"
    doc += "\n   - Use appropriate warehouse sizes"
    doc += "\n   - Consider using resource monitors"
    doc += "\n   - Implement proper data retention policies"
    
    return doc

def process_files(hive_dir: Path, snowflake_dir: Path, doc_dir: Path) -> None:
    """Process SQL files and create documentation"""
    logger = logging.getLogger(__name__)
    converter = HiveToSnowflakeConverter()
    
    # Create docs directory
    doc_dir.mkdir(exist_ok=True)
    
    # Process each Hive SQL file
    for hive_file in hive_dir.glob('*.hql'):
        try:
            # Read Hive SQL
            hive_sql = hive_file.read_text()
            
            # Convert to Snowflake SQL
            snowflake_sql = converter.convert_query(hive_sql)
            
            # Write Snowflake SQL
            snowflake_file = snowflake_dir / hive_file.with_suffix('.sql').name
            snowflake_file.parent.mkdir(exist_ok=True)
            snowflake_file.write_text(snowflake_sql)
            
            # Create documentation
            doc = create_conversion_doc(hive_sql, snowflake_sql, hive_file.name)
            doc_file = doc_dir / f"{hive_file.stem}_conversion.md"
            doc_file.write_text(doc)
            
            logger.info(f"Processed {hive_file.name}")
            
        except Exception as e:
            logger.error(f"Error processing {hive_file.name}: {e}")

def main():
    """Main entry point"""
    logger = setup_logging()
    
    try:
        # Setup directories
        project_root = Path(__file__).parent.parent
        hive_dir = project_root / 'hive_queries'
        snowflake_dir = project_root / 'snowflake_queries'
        doc_dir = project_root / 'sql_converter/docs/conversions'
        
        # Create directories if they don't exist
        for directory in [hive_dir, snowflake_dir, doc_dir]:
            directory.mkdir(exist_ok=True)
        
        # Process files
        logger.info("Starting SQL conversion and documentation")
        process_files(hive_dir, snowflake_dir, doc_dir)
        logger.info("Conversion and documentation completed")
        
    except Exception as e:
        logger.error(f"Error: {e}")
        return 1
    
    return 0

if __name__ == '__main__':
    sys.exit(main()) 